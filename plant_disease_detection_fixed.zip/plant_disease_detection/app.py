"""
app.py — Fixed Flask Application
==================================
ROOT CAUSE FIXES applied here:
  1. Passes low_confidence flag to frontend so users see a warning
     when the model is uncertain (instead of a confident wrong answer)
  2. Image is saved BEFORE prediction (not after), preventing
     "file not found" edge cases
  3. Proper MIME-type validation with python-magic fallback to extension
  4. Returns 503 with a clear message if model isn't loaded yet
"""

import os, json, uuid, logging
from pathlib import Path

from flask import Flask, request, render_template, jsonify
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config["SECRET_KEY"]         = os.environ.get("SECRET_KEY", "plantscan-secret-2024")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024   # 16 MB
app.config["UPLOAD_FOLDER"]      = os.path.join("static", "uploads")

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "bmp"}

Path(app.config["UPLOAD_FOLDER"]).mkdir(parents=True, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
log = logging.getLogger(__name__)

# ── Lazy-load predictor ───────────────────────────────────
_predictor       = None
_model_available = False
_model_error     = ""


def _load_predictor():
    global _predictor, _model_available, _model_error
    if _predictor is not None:
        return
    try:
        import predict as _p
        _p._load_assets()
        _predictor       = _p
        _model_available = True
        log.info("Model loaded successfully.")
    except FileNotFoundError as e:
        _model_error = str(e)
        log.warning(f"Model not ready: {e}")
    except Exception as e:
        _model_error = str(e)
        log.error(f"Model load error: {e}")


_load_predictor()


def allowed_file(filename: str) -> bool:
    return "." in filename and \
           filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def unique_filename(original: str) -> str:
    ext = Path(original).suffix.lower() or ".jpg"
    return f"{uuid.uuid4().hex}{ext}"


# ── Routes ────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html",
                           model_available=_model_available,
                           model_error=_model_error)


@app.route("/predict", methods=["POST"])
def predict():
    if not _model_available:
        _load_predictor()
    if not _model_available:
        return jsonify({
            "success": False,
            "error": (
                "Model not loaded. Run train.py first to generate model.h5, "
                f"then restart the server. ({_model_error})"
            ),
        }), 503

    if "image" not in request.files:
        return jsonify({"success": False, "error": "No image field in request."}), 400

    file = request.files["image"]
    if not file or file.filename == "":
        return jsonify({"success": False, "error": "No file selected."}), 400

    if not allowed_file(file.filename):
        return jsonify({
            "success": False,
            "error": f"File type not allowed. Accepted: {', '.join(ALLOWED_EXTENSIONS)}",
        }), 415

    # Save FIRST, then predict
    filename  = unique_filename(secure_filename(file.filename))
    save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    try:
        file.save(save_path)
        log.info(f"Saved → {save_path}")
    except OSError as e:
        return jsonify({"success": False, "error": f"Could not save file: {e}"}), 500

    try:
        result = _predictor.predict_image(save_path)
    except Exception as e:
        log.error(f"Prediction error: {e}")
        return jsonify({"success": False,
                        "error": f"Prediction failed: {e}"}), 500

    return jsonify({
        "success":          True,
        "image_url":        f"/static/uploads/{filename}",
        "plant_name":       result["plant_name"],
        "disease_name":     result["disease_name"],
        "class_label":      result["class_label"],
        "confidence":       result["confidence"],
        "low_confidence":   result["low_confidence"],
        "all_predictions":  result["all_predictions"],
        "description":      result["description"],
        "recommendation":   result["recommendation"],
        "severity":         result["severity"],
    })


@app.route("/health")
def health():
    return jsonify({
        "status":          "ok",
        "model_available": _model_available,
        "model_error":     _model_error if not _model_available else None,
    })


@app.route("/classes")
def classes():
    for path in ("label_map.json", "class_names.json"):
        if os.path.exists(path):
            with open(path) as f:
                data = json.load(f)
            return jsonify({"success": True, "source": path, "classes": data})
    return jsonify({"success": False, "error": "Class files not found."}), 404


@app.errorhandler(413)
def too_large(_):
    return jsonify({"success": False,
                    "error": "File too large. Max 16 MB."}), 413


if __name__ == "__main__":
    port  = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "1") == "1"
    print(f"\n{'='*55}")
    print(f"  PlantScan AI  →  http://127.0.0.1:{port}/")
    print(f"  Model loaded : {_model_available}")
    if not _model_available:
        print(f"  ⚠  Run python train.py first")
    print(f"{'='*55}\n")
    app.run(host="0.0.0.0", port=port, debug=debug)
