/* ═══════════════════════════════════════════════════════
   PlantScan AI — script.js  (fixed version)
   Key fixes:
     • Shows low-confidence warning banner from API response
     • Colours confidence bar orange when confidence < 45%
     • Detailed top-5 table helps users spot wrong predictions
     • Canvas background (particles + grid)
   ═══════════════════════════════════════════════════════ */

/* ── Animated background ─────────────────────────────── */
(function () {
  const canvas = document.getElementById("bg-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  function resize() { canvas.width = innerWidth; canvas.height = innerHeight; }
  resize();
  addEventListener("resize", resize);
  const pts = Array.from({ length: 26 }, () => ({
    x: Math.random() * innerWidth,  y: Math.random() * innerHeight,
    r: Math.random() * 2.5 + 1,
    dx: (Math.random() - .5) * .32, dy: (Math.random() - .5) * .32,
    a: Math.random() * .3 + .05,
  }));
  (function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    pts.forEach(p => {
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(61,186,94,${p.a})`; ctx.fill();
      p.x += p.dx; p.y += p.dy;
      if (p.x < 0 || p.x > canvas.width)  p.dx *= -1;
      if (p.y < 0 || p.y > canvas.height) p.dy *= -1;
    });
    ctx.strokeStyle = "rgba(61,186,94,0.04)"; ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 60) {
      ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,canvas.height); ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 60) {
      ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(canvas.width,y); ctx.stroke();
    }
    requestAnimationFrame(draw);
  })();
})();

/* ── DOM refs ─────────────────────────────────────────── */
const dropZone    = document.getElementById("drop-zone");
const dropInner   = document.getElementById("drop-inner");
const fileInput   = document.getElementById("file-input");
const previewWrap = document.getElementById("preview-wrap");
const previewImg  = document.getElementById("preview-img");
const previewName = document.getElementById("preview-name");
const btnRemove   = document.getElementById("btn-remove");
const btnAnalyse  = document.getElementById("btn-analyse");
const uploadCard  = document.getElementById("upload-card");
const loadingCard = document.getElementById("loading-card");
const resultCard  = document.getElementById("result-card");
const warnBanner  = document.getElementById("warn-banner");
const errorBlock  = document.getElementById("error-block");
const btnReset    = document.getElementById("btn-reset");
const btnTryAgain = document.getElementById("btn-try-again");
const navHealth   = document.getElementById("nav-health");

let selectedFile = null;

/* ── File selection ──────────────────────────────────── */
fileInput.addEventListener("change", () => {
  if (fileInput.files?.[0]) setFile(fileInput.files[0]);
});

function setFile(file) {
  if (!file.type.startsWith("image/")) {
    toast("⚠ Please select an image file.", "warn"); return;
  }
  selectedFile = file;
  const reader = new FileReader();
  reader.onload = e => {
    previewImg.src = e.target.result;
    previewName.textContent = file.name;
    dropInner.style.display  = "none";
    previewWrap.style.display = "block";
    btnAnalyse.disabled = false;
  };
  reader.readAsDataURL(file);
}

/* ── Drag & Drop ─────────────────────────────────────── */
dropZone.addEventListener("click", e => {
  if (e.target === btnRemove || e.target.closest("#btn-remove")) return;
  fileInput.click();
});
dropZone.addEventListener("dragover",  e => { e.preventDefault(); dropZone.classList.add("drag-over"); });
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("drag-over"));
dropZone.addEventListener("drop", e => {
  e.preventDefault(); dropZone.classList.remove("drag-over");
  if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]);
});

btnRemove.addEventListener("click", e => { e.stopPropagation(); resetUpload(); });

function resetUpload() {
  selectedFile = null; fileInput.value = "";
  previewImg.src = "#"; previewName.textContent = "";
  previewWrap.style.display = "none";
  dropInner.style.display   = "flex";
  btnAnalyse.disabled = true;
}

/* ── Analyse ─────────────────────────────────────────── */
btnAnalyse.addEventListener("click", runPrediction);

async function runPrediction() {
  if (!selectedFile) return;
  uploadCard.style.display  = "none";
  resultCard.style.display  = "none";
  loadingCard.style.display = "flex";
  animateSteps();

  const fd = new FormData();
  fd.append("image", selectedFile);

  try {
    const res  = await fetch("/predict", { method: "POST", body: fd });
    const data = await res.json();
    loadingCard.style.display = "none";
    if (data.success) {
      renderResult(data);
      resultCard.style.display = "block";
    } else {
      showError(data.error || "Unknown error.");
      resultCard.style.display = "block";
    }
  } catch (err) {
    loadingCard.style.display = "none";
    showError("Network error: " + err.message);
    resultCard.style.display = "block";
  }
}

function animateSteps() {
  const ids = ["step-1","step-2","step-3"];
  ids.forEach(id => document.getElementById(id)?.classList.remove("active"));
  document.getElementById("step-1")?.classList.add("active");
  let i = 0;
  const iv = setInterval(() => {
    i++; if (i >= ids.length) { clearInterval(iv); return; }
    ids.forEach(id => document.getElementById(id)?.classList.remove("active"));
    document.getElementById(ids[i])?.classList.add("active");
  }, 900);
}

/* ── Render result ───────────────────────────────────── */
function renderResult(data) {
  /* Reset error / warning state */
  errorBlock.style.display = "none";
  document.querySelectorAll(".result-header,.tabs").forEach(el => el.style.removeProperty("display"));

  /* ── FIX: low-confidence warning ── */
  if (data.low_confidence) {
    warnBanner.style.display = "flex";
  } else {
    warnBanner.style.display = "none";
  }

  /* Image */
  document.getElementById("result-img").src = data.image_url || previewImg.src;

  /* Severity badge */
  const badge = document.getElementById("severity-badge");
  const sev = (data.severity || "None").toLowerCase();
  badge.textContent = data.severity || "None";
  badge.className = "result-badge " +
    (sev === "none" ? "severity-none" : sev === "high" ? "severity-high" : "severity-moderate");

  /* Names */
  document.getElementById("result-plant").textContent   = data.plant_name   || "—";
  document.getElementById("result-disease").textContent = data.disease_name || "—";
  document.getElementById("info-plant").textContent     = data.plant_name   || "—";
  document.getElementById("info-disease").textContent   = data.disease_name || "—";
  document.getElementById("info-severity").textContent  = data.severity     || "—";

  /* Confidence */
  const conf = data.confidence || 0;
  const confEl = document.getElementById("conf-value");
  confEl.textContent = conf.toFixed(1) + "%";
  confEl.className   = "conf-value" + (data.low_confidence ? " low" : "");
  document.getElementById("info-conf").textContent = conf.toFixed(1) + "%";

  const bar = document.getElementById("conf-bar");
  bar.className = "conf-bar-fill" + (data.low_confidence ? " low" : "");
  setTimeout(() => { bar.style.width = conf + "%"; }, 120);

  /* Texts */
  document.getElementById("desc-text").textContent = data.description    || "—";
  document.getElementById("rec-text").textContent  = data.recommendation || "—";

  /* Top-5 */
  const list = document.getElementById("predictions-list");
  list.innerHTML = "";
  (data.all_predictions || []).forEach((p, idx) => {
    const item = document.createElement("div");
    item.className = "pred-item" + (idx === 0 ? " is-top" : "");
    item.innerHTML = `
      <div>
        <div class="pred-label">${p.plant} — ${p.disease}</div>
        <div class="pred-bar-track">
          <div class="pred-bar-fill" style="width:0%" data-target="${p.confidence}"></div>
        </div>
      </div>
      <div class="pred-pct">${p.confidence.toFixed(1)}%</div>`;
    list.appendChild(item);
  });
  setTimeout(() => {
    list.querySelectorAll(".pred-bar-fill").forEach((el, i) => {
      setTimeout(() => { el.style.width = el.dataset.target + "%"; }, i * 90);
    });
  }, 150);

  activateTab("overview");
}

/* ── Error ───────────────────────────────────────────── */
function showError(msg) {
  errorBlock.style.display = "flex";
  document.getElementById("error-msg").textContent = msg;
  document.querySelectorAll(".tab-panel").forEach(p => p.style.display = "none");
  document.querySelectorAll(".result-header,.tabs").forEach(el => el.style.display = "none");
  warnBanner.style.display = "none";
}

/* ── Tabs ─────────────────────────────────────────────── */
document.querySelectorAll(".tab").forEach(btn =>
  btn.addEventListener("click", () => activateTab(btn.dataset.tab))
);
function activateTab(name) {
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  document.querySelectorAll(".tab-panel").forEach(p => {
    p.style.display = p.id === `panel-${name}` ? "block" : "none";
  });
}

/* ── Reset buttons ───────────────────────────────────── */
[btnReset, btnTryAgain].forEach(btn => {
  if (!btn) return;
  btn.addEventListener("click", () => {
    resultCard.style.display = "none";
    uploadCard.style.display = "block";
    document.querySelectorAll(".result-header,.tabs").forEach(el => el.style.removeProperty("display"));
    resetUpload();
  });
});

/* ── Health check ────────────────────────────────────── */
navHealth?.addEventListener("click", async () => {
  try {
    const data = await (await fetch("/health")).json();
    toast(
      data.model_available
        ? "✅ Server healthy — model loaded."
        : `⚠ Model not loaded: ${data.model_error || "run train.py"}`,
      data.model_available ? "ok" : "warn"
    );
  } catch { toast("❌ Server not reachable.", "error"); }
});

/* ── Toast ───────────────────────────────────────────── */
function toast(msg, type = "ok") {
  document.querySelector(".toast")?.remove();
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = msg;
  const colors = {
    ok:   ["rgba(61,186,94,.2)",  "rgba(61,186,94,.5)",  "#6ee08a"],
    warn: ["rgba(212,135,78,.2)", "rgba(212,135,78,.5)", "#d4874e"],
    error:["rgba(224,92,92,.2)",  "rgba(224,92,92,.5)",  "#e05c5c"],
  };
  const [bg, border, color] = colors[type] || colors.ok;
  Object.assign(el.style, {
    position:"fixed", bottom:"24px", right:"24px",
    padding:"12px 20px", borderRadius:"12px",
    fontFamily:"var(--font-b)", fontSize:".88rem",
    maxWidth:"380px", boxShadow:"0 8px 32px rgba(0,0,0,.5)",
    zIndex:"9999", animation:"fadeup .3s ease",
    background:bg, border:`1px solid ${border}`, color,
  });
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 4500);
}
