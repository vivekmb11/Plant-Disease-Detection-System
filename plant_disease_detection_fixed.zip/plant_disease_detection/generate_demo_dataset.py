"""
generate_demo_dataset.py
========================
Creates a minimal demo dataset with synthetic images so you can run
train.py immediately without real plant photos.

Each class gets 80 training-style images (random colour noise + tint).

Run:  python generate_demo_dataset.py
Then: python train.py
Then: python app.py
"""

import os
import random
from pathlib import Path
import numpy as np
from PIL import Image, ImageFilter, ImageDraw

CLASSES = [
    # (folder_name, base_hue_RGB, label)
    ("Potato_Healthy",       (80,  160, 60),  "healthy"),
    ("Potato_Early_blight",  (120, 100, 40),  "diseased"),
    ("Potato_Late_blight",   (60,  80,  50),  "diseased"),
    ("Tomato_Healthy",       (70,  180, 55),  "healthy"),
    ("Tomato_Bacterial_spot",(100, 130, 50),  "diseased"),
    ("Tomato_Late_blight",   (55,  90,  45),  "diseased"),
    ("Tomato_Leaf_mold",     (90,  115, 60),  "diseased"),
    ("Rose_Healthy",         (60,  170, 55),  "healthy"),
    ("Rose_Black_spot",      (50,  70,  40),  "diseased"),
    ("Rose_Powdery_mildew",  (200, 200, 190), "diseased"),
    ("Corn_Healthy",         (85,  175, 50),  "healthy"),
    ("Corn_Common_rust",     (160, 100, 40),  "diseased"),
    ("Corn_Gray_leaf_spot",  (130, 130, 100), "diseased"),
    ("Wheat_Healthy",        (180, 190, 80),  "healthy"),
    ("Wheat_Yellow_rust",    (200, 180, 40),  "diseased"),
    ("Wheat_Brown_rust",     (160, 110, 50),  "diseased"),
]

IMAGES_PER_CLASS = 80
IMG_SIZE         = (224, 224)
DATASET_DIR      = Path("dataset")


def make_leaf_image(base_color: tuple, label: str, size=(224, 224)) -> Image.Image:
    """Generate a synthetic 'leaf-like' image for training."""
    r0, g0, b0 = base_color
    arr = np.zeros((*size, 3), dtype=np.uint8)

    # Fill with colour noise
    noise = np.random.randint(-35, 35, (*size, 3))
    arr[:, :, 0] = np.clip(r0 + noise[:, :, 0], 0, 255)
    arr[:, :, 1] = np.clip(g0 + noise[:, :, 1], 0, 255)
    arr[:, :, 2] = np.clip(b0 + noise[:, :, 2], 0, 255)

    img = Image.fromarray(arr)
    draw = ImageDraw.Draw(img)

    # Draw a simple leaf outline
    cx, cy = size[0] // 2, size[1] // 2
    leaf_pts = [
        (cx, cy - 70), (cx + 50, cy - 30), (cx + 60, cy + 20),
        (cx + 30, cy + 70), (cx, cy + 80), (cx - 30, cy + 70),
        (cx - 60, cy + 20), (cx - 50, cy - 30),
    ]
    draw.polygon(leaf_pts, fill=tuple(np.clip([r0+10, g0+20, b0+10], 0, 255).tolist()))

    # If diseased, add spots
    if label == "diseased":
        for _ in range(random.randint(3, 8)):
            sx = random.randint(cx-50, cx+50)
            sy = random.randint(cy-50, cy+50)
            sr = random.randint(4, 14)
            draw.ellipse([sx-sr, sy-sr, sx+sr, sy+sr],
                         fill=tuple(np.clip([r0-60, g0-60, b0-60], 0, 255).tolist()))

    # Slight blur for realism
    img = img.filter(ImageFilter.GaussianBlur(radius=1))
    return img


def main():
    created = 0
    for folder, base_color, label in CLASSES:
        class_dir = DATASET_DIR / folder
        class_dir.mkdir(parents=True, exist_ok=True)
        for i in range(IMAGES_PER_CLASS):
            img = make_leaf_image(base_color, label)
            img.save(class_dir / f"{folder}_{i:04d}.jpg", "JPEG", quality=90)
            created += 1

    print(f"\n✅ Dataset created: {created} images across {len(CLASSES)} classes")
    print(f"   Location: {DATASET_DIR.resolve()}")
    print("\n▶  Next step:  python train.py\n")


if __name__ == "__main__":
    main()
