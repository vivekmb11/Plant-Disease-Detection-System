"""
predict.py — Fixed Prediction Module
=====================================
ROOT CAUSE FIXES applied here:
  1. Loads class order from label_map.json (index→name) — the SAME
     file written by train.py — so the mapping can NEVER be wrong.
  2. Uses keras.applications.mobilenet_v2.preprocess_input()
     which scales to [-1,1] — EXACTLY matching what train.py did.
     (Old bug: PIL / numpy gave [0,255] raw values to a model that
      expected [-1,1], causing completely wrong predictions.)
  3. Confidence threshold: if top confidence < 45% we warn the user
     instead of confidently returning a wrong answer.
  4. CLI mode prints a full ranked list for easy debugging.

Usage (CLI):
    python predict.py path/to/image.jpg
"""

import os, sys, json
import numpy as np
from PIL import Image
import tensorflow as tf
from tensorflow.keras.models import load_model
import tensorflow.keras.applications.mobilenet_v2 as mbv2

# ── Paths ─────────────────────────────────────────────────
MODEL_PATH   = "model.h5"
CLASSES_PATH = "class_names.json"
LABEL_MAP    = "label_map.json"      # index → class name
IMG_SIZE     = (224, 224)
LOW_CONF_THR = 45.0   # % below which we flag "uncertain"

# ── Disease knowledge base ────────────────────────────────
DISEASE_INFO = {
    "Potato_Healthy":         {"description":"The potato plant appears healthy. Leaves are vibrant green with no spots or lesions.","recommendation":"Continue regular monitoring, balanced irrigation and crop rotation.","severity":"None"},
    "Potato_Early_blight":    {"description":"Early blight (Alternaria solani) produces dark-brown concentric ring spots on older leaves, thriving in warm humid conditions.","recommendation":"Apply chlorothalonil or mancozeb fungicide. Remove infected leaves. Avoid overhead watering.","severity":"Moderate"},
    "Potato_Late_blight":     {"description":"Late blight (Phytophthora infestans) causes water-soaked dark lesions on leaves and stems. Highly destructive.","recommendation":"Apply metalaxyl systemically. Destroy infected plants. Plant resistant varieties next season.","severity":"High"},
    "Tomato_Healthy":         {"description":"The tomato plant is healthy with lush green foliage and no signs of infection.","recommendation":"Maintain consistent watering and scout regularly for early pest detection.","severity":"None"},
    "Tomato_Bacterial_spot":  {"description":"Bacterial spot (Xanthomonas spp.) causes small water-soaked dark spots on leaves and fruit.","recommendation":"Use copper-based bactericides. Remove infected material. Avoid overhead irrigation.","severity":"Moderate"},
    "Tomato_Late_blight":     {"description":"Late blight on tomato produces greasy dark lesions on leaves and brown firm rot on fruit.","recommendation":"Spray mancozeb or copper fungicide. Improve air circulation. Remove infected debris.","severity":"High"},
    "Tomato_Leaf_mold":       {"description":"Tomato leaf mold (Passalora fulva) shows pale yellow spots on upper leaves with olive-grey mold beneath.","recommendation":"Improve ventilation. Apply sulfur fungicide. Remove heavily infected leaves.","severity":"Moderate"},
    "Rose_Healthy":           {"description":"The rose plant is in excellent health with vibrant disease-free foliage.","recommendation":"Continue regular pruning, balanced feeding and monitoring for aphids.","severity":"None"},
    "Rose_Black_spot":        {"description":"Black spot (Diplocarpon rosae) produces circular black spots with fringed margins, causing defoliation.","recommendation":"Apply trifloxystrobin fungicide. Remove fallen leaves immediately. Water at ground level only.","severity":"Moderate"},
    "Rose_Powdery_mildew":    {"description":"Powdery mildew (Podosphaera pannosa) covers young leaves and buds with white powdery growth.","recommendation":"Spray potassium bicarbonate or neem oil. Improve air circulation. Reduce nitrogen fertilisation.","severity":"Moderate"},
    "Corn_Healthy":           {"description":"The corn plant is healthy with no evidence of disease.","recommendation":"Maintain proper spacing and scout regularly for pests such as corn borers.","severity":"None"},
    "Corn_Common_rust":       {"description":"Common rust (Puccinia sorghi) forms brick-red pustules on both sides of leaves.","recommendation":"Apply triazole or strobilurin fungicides at early onset. Use resistant hybrids.","severity":"Moderate"},
    "Corn_Gray_leaf_spot":    {"description":"Gray leaf spot (Cercospora zeae-maydis) creates rectangular tan-to-grey lesions parallel to leaf veins.","recommendation":"Use resistant varieties. Apply azoxystrobin at tasselling. Practice crop rotation.","severity":"High"},
    "Wheat_Healthy":          {"description":"The wheat crop is healthy with green disease-free leaves.","recommendation":"Monitor for aphids, maintain soil moisture and apply balanced NPK fertiliser.","severity":"None"},
    "Wheat_Yellow_rust":      {"description":"Yellow stripe rust (Puccinia striiformis) forms yellow-orange powdery stripes along leaves.","recommendation":"Apply tebuconazole or propiconazole immediately. Use resistant varieties.","severity":"High"},
    "Wheat_Brown_rust":       {"description":"Brown rust (Puccinia triticina) produces small round orange-brown pustules scattered on leaves.","recommendation":"Apply fungicide at flag-leaf stage. Use disease-resistant cultivars.","severity":"Moderate"},
}

_DEFAULT_HEALTHY  = {"description":"Plant appears healthy.","recommendation":"Monitor regularly.","severity":"None"}
_DEFAULT_DISEASED = {"description":"Disease detected. Consult an agronomist for precise diagnosis.","recommendation":"Isolate plant, improve air circulation and consider a broad-spectrum fungicide.","severity":"Moderate"}

# ── Lazy-loaded globals ───────────────────────────────────
_model       = None
_class_names = None   # ordered list  [idx] → name
_label_map   = None   # dict str(idx) → name  (ground truth from train)


def _load_assets():
    global _model, _class_names, _label_map

    if _model is not None:
        return

    # ── Load model ────────────────────────────────────────
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            f"'{MODEL_PATH}' not found. Run train.py first.")
    _model = load_model(MODEL_PATH)

    # ── FIX: Load class order from label_map.json first ──
    # label_map.json is written by train.py with the exact
    # integer-index → class-name mapping the model was trained on.
    if os.path.exists(LABEL_MAP):
        with open(LABEL_MAP) as f:
            raw = json.load(f)
        # Convert {"0":"Corn_Common_rust", "1":...} → ordered list
        max_idx      = max(int(k) for k in raw.keys())
        _class_names = [raw[str(i)] for i in range(max_idx + 1)]
        _label_map   = raw
        print(f"[predict] Loaded class order from {LABEL_MAP} "
              f"({len(_class_names)} classes)")
    elif os.path.exists(CLASSES_PATH):
        # Fallback: class_names.json (must be trusted)
        with open(CLASSES_PATH) as f:
            _class_names = json.load(f)
        print(f"[predict] Loaded class order from {CLASSES_PATH} "
              f"({len(_class_names)} classes)")
    else:
        raise FileNotFoundError(
            "Neither label_map.json nor class_names.json found. "
            "Run train.py first.")


# ── Core predict function ────────────────────────────────
def predict_image(image_path: str) -> dict:
    """
    Returns dict with: plant_name, disease_name, class_label,
    confidence, low_confidence (bool), all_predictions,
    description, recommendation, severity.
    """
    _load_assets()

    # ── Load & preprocess ─────────────────────────────────
    img = Image.open(image_path).convert("RGB").resize(IMG_SIZE)
    arr = np.array(img, dtype=np.float32)           # [0, 255]
    arr = np.expand_dims(arr, axis=0)               # (1,224,224,3)

    # FIX: Must match train.py preprocessing.
    # MobileNetV2 was trained with preprocess_input → [-1, 1].
    # Sending raw [0,255] values causes completely wrong predictions.
    arr = mbv2.preprocess_input(arr)                # [-1, 1]

    # ── Inference ─────────────────────────────────────────
    preds      = _model.predict(arr, verbose=0)[0]  # (num_classes,)
    top_idx    = int(np.argmax(preds))
    confidence = float(preds[top_idx]) * 100.0
    label      = _class_names[top_idx]

    # ── Parse Plant / Disease ─────────────────────────────
    parts        = label.split("_", 1)
    plant_name   = parts[0]
    disease_name = parts[1].replace("_", " ") if len(parts) > 1 else "Unknown"

    # ── Knowledge base lookup ─────────────────────────────
    info = DISEASE_INFO.get(label)
    if info is None:
        info = _DEFAULT_HEALTHY if "healthy" in label.lower() else _DEFAULT_DISEASED

    # ── Top-5 predictions ─────────────────────────────────
    indexed = sorted(enumerate(preds), key=lambda x: x[1], reverse=True)[:5]
    all_preds = [
        {
            "label":      _class_names[i],
            "plant":      _class_names[i].split("_", 1)[0],
            "disease":    _class_names[i].split("_", 1)[1].replace("_"," ")
                          if "_" in _class_names[i] else _class_names[i],
            "confidence": round(float(v) * 100, 2),
        }
        for i, v in indexed
    ]

    # ── Low-confidence warning ────────────────────────────
    low_confidence = confidence < LOW_CONF_THR

    return {
        "plant_name":      plant_name,
        "disease_name":    disease_name,
        "class_label":     label,
        "confidence":      round(confidence, 2),
        "low_confidence":  low_confidence,
        "all_predictions": all_preds,
        "description":     info["description"],
        "recommendation":  info["recommendation"],
        "severity":        info["severity"],
    }


# ── CLI ───────────────────────────────────────────────────
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python predict.py <image_path>")
        sys.exit(1)

    path = sys.argv[1]
    if not os.path.exists(path):
        print(f"File not found: {path}"); sys.exit(1)

    r = predict_image(path)
    print(f"\n{'='*55}")
    print(f"  Plant       : {r['plant_name']}")
    print(f"  Disease     : {r['disease_name']}")
    print(f"  Confidence  : {r['confidence']:.1f}%"
          + (" ← LOW CONFIDENCE" if r['low_confidence'] else ""))
    print(f"  Severity    : {r['severity']}")
    print(f"\n  Top-5 predictions:")
    for i, p in enumerate(r['all_predictions']):
        bar = "█" * int(p['confidence'] / 5)
        print(f"    [{i+1}] {p['label']:35s} {p['confidence']:5.1f}%  {bar}")
    print(f"{'='*55}\n")
